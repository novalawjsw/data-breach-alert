# 500만명 이상 개인정보 유출 알리미 🚨

서버 없이 GitHub Actions를 통해 6시간마다 자동으로 뉴스를 검색하고, 조건에 맞는 뉴스가 있으면 텔레그램으로 알림을 보냅니다.

## 🚀 배포 방법 (3단계)

1. **Fork 또는 새 Repository 생성**: 본 저장소의 코드를 본인의 GitHub Repository에 업로드합니다.
2. **API 키 발급**:
   - [네이버 개발자 센터](https://developers.naver.com/)에서 '검색' API 애플리케이션 생성 (Client ID, Secret 발급)
   - 텔레그램에서 `@BotFather`를 통해 봇 생성 (Token 발급) 및 본인 Chat ID 확인
3. **GitHub Secrets 설정**:
   - Repository의 `Settings > Secrets and variables > Actions` 로 이동하여 `New repository secret` 클릭.
   - 아래 4개의 값을 등록합니다:
     - `NAVER_CLIENT_ID`
     - `NAVER_CLIENT_SECRET`
     - `TELEGRAM_BOT_TOKEN`
     - `TELEGRAM_CHAT_ID`

4. **완료!** 
이제 `Actions` 탭에서 수동으로 `Run workflow`를 눌러 테스트해보거나 6시간을 기다리면 자동으로 뉴스를 스크래핑합니다.
