# 500만명 이상 개인정보 유출 알리미 🚨 (구글 뉴스 버전)

서버 없이 GitHub Actions를 통해 6시간마다 자동으로 구글 뉴스를 검색하고, 조건에 맞는 뉴스가 있으면 텔레그램으로 알림을 보냅니다.

## 🚀 배포 방법 (3단계)

1. **GitHub 업로드**: 본 저장소의 코드를 본인의 GitHub 새 Repository에 업로드합니다.
2. **텔레그램 키 발급**:
   - 텔레그램에서 `@BotFather`를 통해 봇 생성 후 `Token` 발급
   - 텔레그램에서 `@getmyid_bot`을 통해 본인의 `Chat ID` 확인
3. **GitHub Secrets 설정**:
   - Repository의 `Settings > Secrets and variables > Actions` 로 이동하여 `New repository secret` 클릭.
   - 아래 2개의 값을 등록합니다:
     - `TELEGRAM_BOT_TOKEN`
     - `TELEGRAM_CHAT_ID`

4. **완료!** 
이제 `Actions` 탭에서 수동으로 `Run workflow`를 눌러 테스트해보거나 6시간을 기다리면 자동으로 뉴스를 스크래핑합니다.
