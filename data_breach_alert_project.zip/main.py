import os
import re
import json
import requests

# 환경 변수에서 시크릿 키 로드 (GitHub Actions Secrets)
NAVER_CLIENT_ID = os.getenv("NAVER_CLIENT_ID")
NAVER_CLIENT_SECRET = os.getenv("NAVER_CLIENT_SECRET")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

DB_PATH = "seen_articles.json"

def load_db():
    if os.path.exists(DB_PATH):
        with open(DB_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def save_db(db):
    with open(DB_PATH, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

def parse_victim_count(text):
    clean_text = text.replace("<b>", "").replace("</b>", "").replace("&quot;", '"')
    match_eok = re.findall(r'([\d,.]+)\s*억', clean_text)
    for num_str in match_eok:
        if int(float(num_str.replace(',', '')) * 100_000_000) >= 5_000_000: return True
    match_man = re.findall(r'([\d,.]+)\s*만', clean_text)
    for num_str in match_man:
        if int(float(num_str.replace(',', '')) * 10_000) >= 5_000_000: return True
    match_raw = re.findall(r'([\d,]+)\s*(?:명|건|개|계정)', clean_text)
    for num_str in match_raw:
        if int(num_str.replace(',', '')) >= 5_000_000: return True
    return False

def send_telegram_alert(title, link):
    message = f"🚨 [대규모 개인정보 유출 알림]\n\n📌 피해 규모: 500만명 이상 추정\n📰 제목: {title}\n🔗 링크: {link}"
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    requests.post(url, json={"chat_id": TELEGRAM_CHAT_ID, "text": message})

def check_news():
    if not all([NAVER_CLIENT_ID, NAVER_CLIENT_SECRET, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID]):
        print("API Key is missing.")
        return

    query = "개인정보 유출"
    url = f"https://openapi.naver.com/v1/search/news.json?query={query}&display=30&sort=date"
    headers = {"X-Naver-Client-Id": NAVER_CLIENT_ID, "X-Naver-Client-Secret": NAVER_CLIENT_SECRET}
    
    response = requests.get(url, headers=headers)
    if response.status_code != 200: return
    
    seen_links = load_db()
    items = response.json().get("items", [])
    
    for item in items:
        link = item.get("originallink") or item.get("link")
        title = item.get("title", "")
        full_text = f"{title} {item.get('description', '')}"
        
        if link in seen_links: continue
        
        if parse_victim_count(full_text):
            clean_title = title.replace("<b>", "").replace("</b>", "").replace("&quot;", '"')
            send_telegram_alert(clean_title, link)
        
        seen_links.append(link)
        
    save_db(seen_links[-500:]) # Keep only latest 500 to prevent large DB

if __name__ == "__main__":
    check_news()
